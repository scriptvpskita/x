from .restart_logger import RestartLogger


class LoggerAPIService(RestartLogger):
    pass
