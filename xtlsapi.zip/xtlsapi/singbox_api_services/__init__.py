from .stats import StatsAPIService



class APIService(StatsAPIService):
    pass
